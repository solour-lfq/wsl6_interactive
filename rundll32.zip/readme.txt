This dll file was download from http://www.dll-files-download.com/
If you want to get more help and dll files,please go to "http://www.dll-files-download.com/"
���ĵ�ַ��http://www.icrcb.org.cn/